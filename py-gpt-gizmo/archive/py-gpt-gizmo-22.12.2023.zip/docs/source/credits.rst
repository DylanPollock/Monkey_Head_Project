Credits
======================

**Official website:**
https://pygpt.net

**Github:**
https://github.com/szczyglis-dev/py-gpt

**Snap Store:**
https://snapcraft.io/pygpt

**PyPI:**
https://pypi.org/project/pygpt-net

**Author:**
Marcin Szczygliński (Poland, EU)

**Contact:**
info@pygpt.net

**License:**
MIT License


Special thanks
======================
GitHub community for their support and help:

**kaneda2004** - for pull request with ORGANIZATION Key support
