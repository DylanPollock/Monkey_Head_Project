
Coming soon
===========

- Enhanced integration with Langchain
- Vector databases support
- Development of autonomous agents