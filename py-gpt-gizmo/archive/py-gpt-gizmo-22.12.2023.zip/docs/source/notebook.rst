Notebook
===========

The application has a built-in notebook, divided into several tabs. This can be useful for storing informations in a convenient way, without the need to open an external text editor. The content of the notebook is automatically saved whenever the content changes.

.. image:: images/v2_notepad.png
   :width: 600