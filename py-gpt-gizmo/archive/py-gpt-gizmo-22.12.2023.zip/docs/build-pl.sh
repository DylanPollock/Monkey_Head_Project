make -e SPHINXOPTS="-D language='pl'" html
make latexpdf -e SPHINXOPTS="-D language='pl'"