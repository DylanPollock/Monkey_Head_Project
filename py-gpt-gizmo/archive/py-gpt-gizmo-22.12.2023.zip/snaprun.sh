#!/bin/bash

python3 $SNAP/src/pygpt_net/app.py