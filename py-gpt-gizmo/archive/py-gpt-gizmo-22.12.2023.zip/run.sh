#!/bin/bash

source ./venv/bin/activate
python3 ./src/pygpt_net/app.py