import unittest


class TestMain(unittest.TestCase):
    # TODO: Write these tests.

    def test_main(self):
        self.assertEqual(1, 1)


if __name__ == "__main__":
    unittest.main()
