#!/bin/bash

source ./venv/bin/activate
python3 run.py